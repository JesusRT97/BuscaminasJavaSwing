import java.awt.Color;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

//Clase FuncionalidadJuego donde controlaremos el curso del juego
/**
 * Clase que representa la funcionalidad del juego
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 */
public class FuncionalidadJuego {

	/**
	 * Matriz de casillas (tablero)
	 * 
	 * @since 1.0
	 */
	public Casilla[][] matrizCasillas;

	/**
	 * Tamanio de la fila y columna
	 * 
	 * @since 1.0
	 */
	public int tam_fila_col; // tamanio de las filas y las columnas

	// establecemos las ImageIcon de la bomba, la bandera y sin pulsar como
	// constantes
	/**
	 * Imagen de la bomba
	 * 
	 * @since 1.0
	 */
	static final ImageIcon imagenBomba = new ImageIcon("src/mina.png");

	/**
	 * Imagen de la bandera
	 * 
	 * @since 1.0
	 */
	static final ImageIcon imagenBandera = new ImageIcon("src/bandera.png");

	/**
	 * Imagen por defecto(sin imagen)
	 * 
	 * @since 1.0
	 */
	static final ImageIcon imagenPorDefecto = new ImageIcon("");

	// construcor por defecto
	/**
	 * Construye una FuncionalidadJuego con atributos a <code> null </code>
	 * 
	 * @since 1.0
	 */
	public FuncionalidadJuego() {
		super();
	}

	// constructor en el que le pasamos la matriz de casilla por parametro y el
	// tama�o de las filas y columnas
	/**
	 * Contruye una FuncionalidadJuego con los parametros indicados
	 * 
	 * @param matrizCasilla Matriz de casillas
	 * @param tam_fila_col  Tama�o de filas y columnas
	 * 
	 *                      since 1.0
	 */
	public FuncionalidadJuego(Casilla[][] matrizCasilla, int tam_fila_col) {
		super();
		this.matrizCasillas = matrizCasilla;
		this.tam_fila_col = tam_fila_col;
	}

	// metodo que se encarga de ver como transcurre el juego que recibe la posicion
	// de la fila y la columna mas el click que se ha pulsado
	/**
	 * Encargado de ver como transcurre el juego
	 * 
	 * @param clickPulsado    Click que se ha pulsado
	 * @param posicionFila    Posicion de la fila
	 * @param posicionColumna Posicion de la columna
	 */
	public void juego(int clickPulsado, int posicionFila, int posicionColumna) {

		// establecemos el numero de casillas que deben estar deshabilitadas para ganar
		int numCasillasDesabilitadasParaGanar = (tam_fila_col * tam_fila_col) - cuentaNumeroMinas();

		// si pulsamos el boton izquierdo
		if (clickPulsado == MouseEvent.BUTTON1) {
			funcionamientoClickIzquierdo(posicionFila, posicionColumna, numCasillasDesabilitadasParaGanar);

			// si pulsamos el boton derecho
		} else if (clickPulsado == MouseEvent.BUTTON3) {
			funcionamientoClickDerecho(posicionFila, posicionColumna);
		}

	}

	// metodo encargado de comprobar que sucede al pulsar el click derecho
	/**
	 * Comprueba que sucede al pulsar el click derecho
	 * 
	 * @param posicionFila    Posicion de la fila
	 * @param posicionColumna Posicion de la columna
	 */
	private void funcionamientoClickDerecho(int posicionFila, int posicionColumna) {
		// si una casilla esta habilitada
		if (matrizCasillas[posicionFila][posicionColumna].isEnabled()) {
			// si hay bandera
			if (matrizCasillas[posicionFila][posicionColumna].siHayBandera() == true) {
				matrizCasillas[posicionFila][posicionColumna].setIcon(FuncionalidadJuego.imagenPorDefecto);
				matrizCasillas[posicionFila][posicionColumna].setHayBandera(false);
			} else {
				matrizCasillas[posicionFila][posicionColumna].setIcon(FuncionalidadJuego.imagenBandera);
				matrizCasillas[posicionFila][posicionColumna].setHayBandera(true);
			}
		}
	}

	// metodo encargado de comprobar que sucede al pulsar el click izquierdo
	/**
	 * Comprueba que sucede al pulsar el click izquierdo en el metodo {@link FuncionalidadJuego#juego(posicionFila, posicionColumna, numCasillasDeshabilitadasParaGanar)}
	 * 
	 * @param posicionFila                      Posicion de la fila
	 * @param posicionColumna                   Posicion de la columna
	 * @param numCasillasDesabilitadasParaGanar Numero de casillas que deben estar
	 *                                          desabilitadas para la victoria
	 */
	private void funcionamientoClickIzquierdo(int posicionFila, int posicionColumna,
			int numCasillasDesabilitadasParaGanar) {
		// si una casilla esta habilitada
		if (matrizCasillas[posicionFila][posicionColumna].isEnabled()) {
			// si hay mina y no hay bandera
			if (matrizCasillas[posicionFila][posicionColumna].siHayMina()
					&& !matrizCasillas[posicionFila][posicionColumna].siHayBandera()) {
				// establecemos la derrota
				derrota();

				// si no hay mina y no hay bandera
			} else if (!matrizCasillas[posicionFila][posicionColumna].siHayMina()
					&& !matrizCasillas[posicionFila][posicionColumna].siHayBandera()) {

				// vemos si hay minas adyacentes mediante este metodo recursivo
				minasAlrededor(posicionFila, posicionColumna);

				// comprobamos si hay victoria
				compruebaVictoria(numCasillasDesabilitadasParaGanar);

			}

		}
	}

	// metodo encargado de comprobar la victoria
	/**
	 * Comprueba si hay victoria
	 * 
	 * @param numCasillasDesabilitadasParaGanar Numero de casillas que deben estar
	 *                                          desabilitadas para la victoria
	 */
	private void compruebaVictoria(int numCasillasDesabilitadasParaGanar) {
		int numeroCasillasDeshabilitadas = 0;

		// vemos el numero de casillas deshabilitadas
		for (int i = 0; i < tam_fila_col; i++) {
			for (int j = 0; j < tam_fila_col; j++) {
				if (!matrizCasillas[i][j].isEnabled()) {
					numeroCasillasDeshabilitadas++;
				}
			}
		}

		// si el numero de casillas deshabilitadas es el mismo que las necesarias para
		// ganar
		if (numCasillasDesabilitadasParaGanar == numeroCasillasDeshabilitadas) {

			// dialogo de victoria
			JOptionPane.showMessageDialog(null, "!Has ganado�");

			// deshabilitamos el resto de las casillas
			for (int i = 0; i < tam_fila_col; i++) {
				for (int j = 0; j < tam_fila_col; j++) {
					matrizCasillas[i][j].setEnabled(false);
				}
			}
		}
	}

	// metodo encargado de establecer la derrota
	/**
	 * Establece la derrota
	 * 
	 * @since 1.0
	 */
	private void derrota() {

		// recorremos todo el tablero
		for (int i = 0; i < tam_fila_col; i++) {
			for (int j = 0; j < tam_fila_col; j++) {

				// si hay mina
				if (matrizCasillas[i][j].siHayMina()) {

					// establecemos el icono de la mina con fondo rojo
					matrizCasillas[i][j].setIcon(FuncionalidadJuego.imagenBomba);
					matrizCasillas[i][j].setDisabledIcon(FuncionalidadJuego.imagenBomba);
					matrizCasillas[i][j].setBackground(Color.RED);

				}
				// deshabilitamos la casillas
				matrizCasillas[i][j].setEnabled(false);
			}
		}

		// dialogo de derrota
		JOptionPane.showMessageDialog(null, "Has pisado una mina. !Has perdido�");
	}

	// metodo recursivo encargado de ver si hay minas adyacentes a la casilla que se
	// ha pulsado
	/**
	 * Establece el numero de bombas adyacentes de forma recursiva
	 * 
	 * 
	 * @param posicionFila    Posicion de la fila
	 * @param posicionColumna Posicion de la columna
	 */
	private void minasAlrededor(int posicionFila, int posicionColumna) {
		// contador de bombas adyacentes
		int numBombas = 0;

		// recorremos las minas adyacentes
		for (int i = Math.max(0, posicionFila - 1); i < Math.min(tam_fila_col, posicionFila + 2); i++) {
			for (int j = Math.max(0, posicionColumna - 1); j < Math.min(tam_fila_col, posicionColumna + 2); j++) {
				// si hay minas
				if (matrizCasillas[i][j].siHayMina() == true) {
					// incrementamos el contador de bombas
					numBombas++;
				}
			}
		}

		// si hay bombas
		if (numBombas > 0) {
			// establecemos el icono con dicho numero y deshabilitamos
			ImageIcon iconoNumBombas = new ImageIcon("src/" + String.valueOf(numBombas) + ".png");
			matrizCasillas[posicionFila][posicionColumna].setIcon(iconoNumBombas);
			matrizCasillas[posicionFila][posicionColumna].setDisabledIcon(iconoNumBombas);
			matrizCasillas[posicionFila][posicionColumna].setEnabled(false);

		} else if (numBombas == 0) {
			// deshabilitamos la imagen
			matrizCasillas[posicionFila][posicionColumna].setIcon(imagenPorDefecto);
			matrizCasillas[posicionFila][posicionColumna].setEnabled(false);

			// para cada una de las posiciones adyacentes vemos si hay minas alrededor (aqui
			// se da la recursividad)
			for (int i = Math.max(0, posicionFila - 1); i < Math.min(tam_fila_col, posicionFila + 2); i++) {
				for (int j = Math.max(0, posicionColumna - 1); j < Math.min(tam_fila_col, posicionColumna + 2); j++) {
					if (matrizCasillas[i][j].isEnabled() && !matrizCasillas[i][j].siHayBandera()) {
						minasAlrededor(i, j);
					}
				}
			}
		}
	}

	// metodo que cuenta y deuelve el numero de minas que hay en total
	/**
	 * Devuelve la cantidad de {@link Casilla#hayMina Hay o no mina} que son
	 * igual a <code> true </code>
	 * 
	 * @return numero de minas del tablero
	 * @since 1.0
	 */
	public int cuentaNumeroMinas() {
		int numeroMinasTotal = 0;
		for (int i = 0; i < tam_fila_col; i++) {
			for (int j = 0; j < tam_fila_col; j++) {
				if (matrizCasillas[i][j].siHayMina()) {
					numeroMinasTotal++;
				}
			}
		}

		return numeroMinasTotal;

	}

	/**
	 * Devuelve un <code>int</code> con el numero total de casillas
	 * 
	 * @deprecated No usamos este metodo para contar las casillas
	 * @return numero total de casillas
	 * @throws Exception si ocurre algun error
	 */
	public int cuentaNumeroCasillas() throws Exception {
		int numeroTotalCasillas = 0;
		for (int i = 0; i < tam_fila_col; i++) {
			for (int j = 0; j < tam_fila_col; j++) {
				numeroTotalCasillas++;
			}
		}

		return numeroTotalCasillas;
	}

}