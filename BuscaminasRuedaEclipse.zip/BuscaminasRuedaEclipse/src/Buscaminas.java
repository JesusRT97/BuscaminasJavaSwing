/**
 * Esta clase representa el juego Buscaminas
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 *
 */
public class Buscaminas {
	
	/**
	 * Objeto de clase FrameInicial
	 * 
	 * @since 1.0
	 */
	private static FrameInicial frameInicio = new FrameInicial();
	
	/**
	 * Metodo principal
	 * 
	 * @param args argumentos del main
	 * @since 1.0
	 */
	public static void main(String[] args) {
		inicio();
	}
	
	//metodo encargado de iniciar el programa cargando el Frame Inicial
	/**
	 * Inicia el frame
	 *	
	 * @since 1.0
	 */
	public static void inicio() {
		
		frameInicio.initComponents();
	}

}