import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

//Clase Casilla que hereda de JButton ya que a parte de la funciones propias de JButton necesitamos otras caracteristicas
/**
 * Clase que representa una casilla del tablero (hereda de JButton)
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 *
 */
public class Casilla extends JButton {

	/**
	 * Hay o no mina en la casilla
	 * 
	 * @since 1.0
	 */
	private boolean hayMina;

	/**
	 * Hay o no mina en la bandera
	 * 
	 * @since 1.0
	 */
	private boolean hayBandera = false;

	/**
	 * Posicion de la fila que ocupa la casilla
	 * 
	 * @since 1.0
	 */
	private int posicionFila;

	/**
	 * Posicion de la columna que ocupa la casilla
	 * 
	 * @since 1.0
	 */
	private int posicionColumna;

	// constructor de la clase Casilla donde daremos comportamiento a la casilla
	/**
	 * Construye una Casilla con los parametros indicados
	 * 
	 * @param posicionFila   Posicion de la fila
	 * @param posicionColumna Posicion de la columna
	 */
	public Casilla(int posicionFila, int posicionColumna) {

		super();
		this.posicionColumna = posicionFila;
		this.posicionColumna = posicionColumna;

		// aqui asignamos a cada casilla una mina dependiendo de la probabilidad
		double minaRandom = Math.random();

		if (minaRandom > SubPanelArriba.dificultad) {
			hayMina = true;
		} else {
			hayMina = false;
		}

		// aniadimos el comportamiento a la casilla dependiendo del click pulsado
		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// obtenemos el boton pulsado
				int clickPulsado = e.getButton();
				// llamada al metodo juego para ver que ocurre en pantalla tras pulsar
				SubPanelCentro.funcionJuego.juego(clickPulsado, posicionFila, posicionColumna);

			}

		});

	}

	/**
	 * Devuelve la posicion de la fila
	 * 
	 * @return posicion de la fila
	 * @see Casilla#posicionFila
	 * @since 1.0
	 */
	public int getPosicionFila() {
		return posicionFila;
	}

	/**
	 * Establece la posicion de la fila que ocupa una casilla
	 * 
	 * @param posicionFila Posicion de la fila
	 * @see Casilla#posicionFila
	 * @since 1.0
	 */
	public void setPosicionFila(int posicionFila) {
		this.posicionFila = posicionFila;
	}

	/**
	 * Devuelve la posicion de la columna
	 * 
	 * @return posicion de la columna
	 * @see Casilla#posicionColumna
	 * @since 1.0
	 */
	public int getPosicionColumna() {
		return posicionColumna;
	}

	/**
	 * Establece la posicion de la columna que ocupa una casilla
	 * 
	 * @param posicionColumna Posicion de la columna
	 * @see Casilla#posicionColumna
	 * @since 1.0
	 */
	public void setPosicionColumna(int posicionColumna) {
		this.posicionColumna = posicionColumna;
	}

	/**
	 * Comprueba si hay mina en la casilla
	 * 
	 * @return <code> true </code> si en la casilla hay mina y <code> false </code> si
	 *         no hay mina
	 * @see Casilla#hayMina
	 * @since 1.0
	 */
	public boolean siHayMina() {
		return hayMina;
	}

	/**
	 * Coloca una mina
	 * 
	 * @param hayMina Hay o no mina
	 * @see Casilla#hayMina
	 * @since 1.0
	 */
	public void setHayMina(boolean hayMina) {
		this.hayMina = hayMina;
	}

	/**
	 * Comprueba si hay bandera en la casilla
	 * 
	 * @return <code> true </code> si en la casilla hay una bandera y <code> false
	 *         </code> si no hay bandera
	 * @see Casilla#hayBandera
	 * @since 1.0
	 */
	public boolean siHayBandera() {
		return hayBandera;
	}
	/**
	 * Coloca una bandera
	 * 
	 * @param hayBandera Hay o no bandera
	 * @see Casilla#hayBandera
	 * @since 1.0
	 */
	public void setHayBandera(boolean hayBandera) {
		this.hayBandera = hayBandera;
	}
}
