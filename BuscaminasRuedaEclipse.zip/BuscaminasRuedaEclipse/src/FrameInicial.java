import java.awt.Dimension;

import javax.swing.JFrame;

//Clase que hereda de JFrame
/**
 * Clase que representa el frame de inicio
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 *
 */
public class FrameInicial extends JFrame{
	
	//creamos un objeto de la clase PanelInicial y lo inicializamos
	/**
	 * Panel inicial donde estableceremos los componentes
	 * 
	 * @since 1.0
	 */
	protected static PanelInicio panelInicio = new PanelInicio();
	
	//constructor por defecto
	/**
	 * Construye un Frame Inicial con atributos a <code> null </code>
	 * 
	 * @since 1.0
	 */
	public FrameInicial() {
		super();
	}
	
	//metodo encargado de establecer los componentes del Frame
	
	/**
	 * Inicia los componentes del FrameInicial
	 * 
	 * @since 1.0
	 */
	public void initComponents(){
		setTitle("Buscaminas");
		setSize(new Dimension(850, 750));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		addPanelInicial();
		setLocationRelativeTo(null);
		setVisible(true);
		
	}
	
	//metodo que aniade el panel al frame
	/**
	 * Aniade el PanelInicial al FrameInicial
	 * 
	 * @since 1.0
	 */
	public void addPanelInicial() {
		
		//establecemos los componentes del panel inicial
		panelInicio.initComponents();
		//aniadimos el panel inicial al frame
		add(panelInicio);
		
	}
}
