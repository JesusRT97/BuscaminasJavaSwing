import java.awt.GridLayout;

//Clase SubPanelCentro que hereda de PanelInicio donde establecemos el buscaminas.
/**
 * Clase que representa al sub panel central
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 *
 */
public class SubPanelCentro extends PanelInicio {
	
	//objeto de tipo Funcionalidad juego que inicializaremos despues
	/**
	 * Funcionalidad del juego
	 * 
	 * @since 1.0
	 */
	public static FuncionalidadJuego funcionJuego;

	//constructor por defecto
	/**
	 * Construye un SubPanelCentro con atributos a <code> null </code>
	 * 
	 * @since 1.0
	 */
	public SubPanelCentro() {
		super();
	}
	
	//metodo encargado de establecer los componentes del panel central
	/**
	 * Inicia los componentes del SubPanelCentro
	 * 
	 * @since 1.0
	 */
	public void initComponents() {
		setLayout(new GridLayout(tam_fila_columna, tam_fila_columna));
		addCasillas();

	}
	
	//metodo encargado de a�adir cada una de las casillas que conforman el buscaminas
	/**
	 * A�ade las casillas al SubPanelCentro
	 * 
	 * @since 1.0
	 */
	public void addCasillas() {
		
		//creamos una matriz o tablero compuesto por elementos de tipo Casilla con el tama�o que establezcamos en la dificultad
		Casilla matrizCasillas[][] = new Casilla[tam_fila_columna][tam_fila_columna];
		
		for (int i = 0; i < tam_fila_columna; i++) {
			for (int j = 0; j < tam_fila_columna; j++) {
				
				
				//asignamos a cada posicion de la matriz una casilla con la posicion de su fila y columna
				matrizCasillas[i][j] = new Casilla(i, j);
				//a�adimos la casilla al panel central
				add(matrizCasillas[i][j]);

			}

		}
		
		//damos funcionalidad al juego inicializando el objeto de tipo FuncionalidadJuego con el constructor que necesita la matriz de Casillas
		funcionJuego = new FuncionalidadJuego(matrizCasillas, tam_fila_columna);

	}
}
