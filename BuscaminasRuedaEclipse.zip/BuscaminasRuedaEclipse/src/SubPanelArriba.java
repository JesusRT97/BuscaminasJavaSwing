import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;

//Clase SubPanelArriba que hereda de PanelInicio donde se configuran los elementos de la parte superior de la ventana.
/**
 * Clase que representa el subpanel de arriba
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 */
public class SubPanelArriba extends PanelInicio {
	
	// Constructor por defecto
	/**
	 * Construye un SubPanelArriba con atributos a <code> null </code>
	 * 
	 * @since 1.0
	 */
	public SubPanelArriba() {
		super();
	}

	// metodo donde establecemos los componentes del panel de arriba
	/**
	 * Inicia los componentes del SubPanelArriba
	 * 
	 * @since 1.0
	 */
	public void initComponents() {

		setLayout(new FlowLayout());
		setForeground(Color.LIGHT_GRAY);
		addComponents();
	}

	// metodo que se encarga de a�adir los componentes al panel de arriba
	/**
	 * A�ade los componentes al SubPanelArriba
	 * 
	 * @since 1.0
	 */
	public void addComponents() {
		
		//establecemos un objeto JLabel con el mensaje de bienvenida
		JLabel mensajeBienvenida = new JLabel("Bienvenido al Buscaminas");
		mensajeBienvenida.setFont(new Font("Arial", Font.BOLD, 20));
		mensajeBienvenida.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 30));
		
		//establecemos un objeto JComboBox de Strings con las dificultasdes
		JComboBox<String> comboDificultad = new JComboBox<String>();

		comboDificultad.addItem("Principiante");
		comboDificultad.addItem("Intermedio");
		comboDificultad.addItem("Experto");
		
		//le damos comportamiento al comboBox
		comboDificultad.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//establecemos un tama�o y dificultad dependiendo de nuestra eleccion
				switch ((String) comboDificultad.getSelectedItem()) {
				case "Principiante": {
					dificultad = 0.9;
					tam_fila_columna = 10;
					break;
				}
				case "Intermedio": {
					dificultad = 0.8;
					tam_fila_columna = 15;
					break;
				}
				case "Experto": {
					dificultad = 0.7;
					tam_fila_columna = 20;
					break;
				}

				}
			}
		});

		JButton comenzar = new JButton("Comenzar");

		// establecemos el comportamiento del boton "Comenzar"
		comenzar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// borramos los componentes del panel central por si ha ocurrido un juego anteriormente 
				// previamente
				panelCentro.removeAll();
				// establecemos los nuevos componentes
				panelCentro.initComponents();
				// actualiazamos el panel central para que se apliquen los componentes
				// establecidos
				panelCentro.revalidate();
				panelCentro.repaint();

				// mediante el metodo removeAll(), revalidate() y repaint() hacemos que el tablero se cargue
				// de forma dinamica cada vez que pulsamos.
			}
		});

		// a�adimos el JLabel de bienvenida y el JButton de comenzar al panel de arriba
		add(mensajeBienvenida);
		add(comboDificultad);
		add(comenzar);
	}

}
