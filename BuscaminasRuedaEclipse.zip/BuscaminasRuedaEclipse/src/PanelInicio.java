import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;

//Clase que hereda de JPanel que estableceremos como panel inicial o principal
/**
 * Clase que representa el panel de inicio
 * 
 * @author Jesus Rueda
 * @version 1.0
 * @since 1.0
 *
 */
public class PanelInicio extends JPanel {

	// creamos un objeto de la clase SubPanelCentro y lo iniciaizamos
	/**
	 * Panel situado en el centro del panel inicial
	 * 
	 * @since 1.0
	 */
	protected static SubPanelCentro panelCentro = new SubPanelCentro();

	// atributo donde estableceremos el "porcentaje" de dificultad por defecto al
	// 10% (es decir que hay un 10% de que haya mina)
	/**
	 * Probabilidad de que haya no haya mina
	 * 
	 * @since 1.0
	 */
	public static double dificultad = 0.9;

	// atributo donde estableceremos el tama�o por defecto a 10 filas y 10 columnas
	/**
	 * Tama�o tanto de la fila como la columna
	 * 
	 * @since 1.0
	 */
	public static int tam_fila_columna = 10;

	// constructor por defecto
	/**
	 * Construye un PanelInicio con atributos a <code> null </code>
	 * 
	 * @since 1.0
	 */
	public PanelInicio() {
		super();
	}

	// metodo encargado establecer los componentes del panel inicial
	/**
	 * Inicia los componentes del PanelInicio
	 * 
	 * @since 1.0
	 */
	public void initComponents() {

		setLayout(new BorderLayout());
		aniadeSubPaneles();

	}

	// metodo encargado de a�adir, en este caso, los distintos subpaneles al panel
	// inicial
	/**
	 * A�ade los subpaneles al PanelInicio
	 * 
	 * @since 1.0
	 */
	public void aniadeSubPaneles() {
		// creamos e inicializamos los objetos de tipo SubPanelArriba y SubPaenlInferior
		SubPanelArriba panelArriba = new SubPanelArriba();
		PanelInferior panelInferior = new PanelInferior();

		// establecemos los componentes del los paneles de arriba e inferior
		panelArriba.initComponents();
		panelInferior.initComponents();

		// a�adimos el panel de arriba, centro e inferior
		add(panelArriba, BorderLayout.NORTH);
		add(panelCentro, BorderLayout.CENTER);
		add(panelInferior, BorderLayout.SOUTH);
	}

	// clase interna PanelInferior que hereda de JPanel donde establecemos el los
	// componentes del panel inferior
	/**
	 * Clase que representa el panel inferior de la ventana (clase interna a
	 * PanelInicio)
	 * 
	 * @author Jesus Rueda
	 * @version 1.0
	 * @since 1.0
	 */
	class PanelInferior extends JPanel {

		// constructor por defecto
		/**
		 * Construye un PanelInferior con atribiutos a <code> null </code>
		 * 
		 * @since 1.0
		 */
		public PanelInferior() {
			super();
		}

		// metodo encargado de establecer los componentes del panel inferior
		/**
		 * Inicia los componentes de PanelInferior
		 * 
		 * @since 1.0
		 */
		public void initComponents() {

			setLayout(new FlowLayout(FlowLayout.LEFT, 10, 5));
			setBackground(Color.BLACK);
			addComponents();

		}

		// metodo a�adir los componentes al panel inferior
		/**
		 * A�ade los componentes al PanelInferior
		 * 
		 * @since 1.0
		 */
		public void addComponents() {

			JLabel mensajeAlumno = new JLabel("Autor: Jesus Rueda Tena");
			mensajeAlumno.setForeground(Color.WHITE);
			mensajeAlumno.setFont(new Font("Arial", Font.ITALIC, 14));
			add(mensajeAlumno);
		}

	}
}
